const express = require("express");
const cors = require("cors");
const session = require("express-session");
const bcrypt = require("bcrypt");
const db = require("./db");

const app = express();

app.use(cors({
  origin: [
    "http://localhost:5173",
    "http://localhost:5174",
    "http://linklibrarian-backend-env.eba-fnyxdkdp.us-west-2.elasticbeanstalk.com"
  ],
  credentials: true,
}));

app.use(express.json());

app.use(session({
  secret: "linklibrarian-secret",
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: false,
  },
}));

app.get("/", (req, res) => {
  res.send("LinkLibrarian Backend Running");
});

app.post("/register", async (req, res) => {
  const { email, password } = req.body;

  const hashedPassword = await bcrypt.hash(password, 10);

  db.query(
    "INSERT INTO users (email, password) VALUES (?, ?)",
    [email, hashedPassword],
    (err, result) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ message: "Registration failed" });
      }

      res.json({ message: "User registered successfully" });
    }
  );
});

app.post("/login", (req, res) => {
  const { email, password } = req.body;

  db.query(
    "SELECT * FROM users WHERE email = ?",
    [email],
    async (err, results) => {
      if (err) {
        return res.status(500).json({ message: "Login failed" });
      }

      if (results.length === 0) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      const user = results[0];
      const isMatch = await bcrypt.compare(password, user.password);

      if (!isMatch) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      req.session.userId = user.id;

      res.json({ message: "Login successful", userId: user.id });
    }
  );
});

app.post("/logout", (req, res) => {
  req.session.destroy(() => {
    res.json({ message: "Logged out" });
  });
});

function requireLogin(req, res, next) {
  if (!req.session.userId) {
    return res.status(401).json({ message: "Not logged in" });
  }

  next();
}

app.get("/links", requireLogin, (req, res) => {
  db.query(
    "SELECT * FROM links WHERE user_id = ? ORDER BY created_at DESC",
    [req.session.userId],
    (err, results) => {
      if (err) return res.status(500).json({ message: "Failed to load links" });
      res.json(results);
    }
  );
});

app.post("/links", requireLogin, (req, res) => {
  const { title, url, notes, tags } = req.body;

  db.query(
    "INSERT INTO links (user_id, title, url, notes, tags) VALUES (?, ?, ?, ?, ?)",
    [req.session.userId, title, url, notes, tags],
    (err, result) => {
      if (err) return res.status(500).json({ message: "Failed to add link" });
      res.json({ message: "Link added", id: result.insertId });
    }
  );
});

app.put("/links/:id", requireLogin, (req, res) => {
  const { title, url, notes, tags } = req.body;

  db.query(
    "UPDATE links SET title = ?, url = ?, notes = ?, tags = ? WHERE id = ? AND user_id = ?",
    [title, url, notes, tags, req.params.id, req.session.userId],
    (err) => {
      if (err) return res.status(500).json({ message: "Failed to update link" });
      res.json({ message: "Link updated" });
    }
  );
});

app.delete("/links/:id", requireLogin, (req, res) => {
  db.query(
    "DELETE FROM links WHERE id = ? AND user_id = ?",
    [req.params.id, req.session.userId],
    (err) => {
      if (err) return res.status(500).json({ message: "Failed to delete link" });
      res.json({ message: "Link deleted" });
    }
  );
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});